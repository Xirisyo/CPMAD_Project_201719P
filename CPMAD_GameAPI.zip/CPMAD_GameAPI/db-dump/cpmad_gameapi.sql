-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2023 at 06:37 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cpmad_gameapi`
--
CREATE DATABASE IF NOT EXISTS `cpmad_gameapi` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cpmad_gameapi`;

-- --------------------------------------------------------

--
-- Table structure for table `leaderboard`
--

CREATE TABLE `leaderboard` (
  `id` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `time` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leaderboard`
--

INSERT INTO `leaderboard` (`id`, `userID`, `score`, `time`, `created_at`, `updated_at`) VALUES
(1, 1, 397, 47, '2023-02-11 10:41:10', '2023-02-13 16:52:30'),
(3, 2, 55, 24, '2023-02-11 10:41:10', '2023-02-13 11:20:29'),
(4, 3, 56, 27, '2023-02-11 10:41:10', '2023-02-13 11:20:29');

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT 'cpmad_placeholder.jpg',
  `coins` int(11) DEFAULT 0,
  `token` varchar(255) DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `image`, `coins`, `token`, `lastLogin`, `created_at`, `updated_at`) VALUES
(1, 'chris', '599e41d8cd8cf1ea79e494df54ede29a', 'blue-lit-xiao-genshin-impact-xg6meyle3w0tz0ca.jpg', 2803, 'Rt85atGJJGY0arUlYLBcb3IDOlyfaBAFekCVEPggQvy6ZNyTco4ewNfyES4y', '2023-02-13 23:56:31', '2023-01-29 15:49:03', '2023-02-13 16:52:30'),
(2, 'chris1', '50fdef3fc386e2c6729f628309cf0b62', 'cpmad_placeholder.jpg', 0, 'w112xjOVHskThNOpV0RXkn5GFcGOfLQkqan5drn4P1QKyT11TDSNY1uJIQpd', '2023-02-07 11:13:32', '2023-02-07 03:13:32', '2023-02-07 03:13:32'),
(3, 'tomsayhi', 'd58e3582afa99040e27b92b13c8f2280', 'cpmad_placeholder.jpg', 0, '5pMG5dKINRBnjgPAHZ7cjPGfHwF6kbpdrW9RCzYdJtlJeuVbFERjADjUKvfa', '2023-02-07 11:43:28', '2023-02-07 03:43:28', '2023-02-13 12:58:51'),
(4, 'wadffsedgaersdg', '6fcdb37569afb4779d5fef0cd2b434e7', 'cpmad_placeholder.jpg', 0, 'avNPcMixmOyKjaYLkSvuhnCKzUOJHQKOQxBKZ629eHrkHjEBAIKky73dYFTM', '2023-02-07 11:43:52', '2023-02-07 03:43:52', '2023-02-07 03:43:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leaderboard`
--
ALTER TABLE `leaderboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leaderboard`
--
ALTER TABLE `leaderboard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `shop`
--
ALTER TABLE `shop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
