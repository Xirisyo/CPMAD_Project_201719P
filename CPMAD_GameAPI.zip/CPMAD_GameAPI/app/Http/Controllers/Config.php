<?php 

namespace App\Http\Controllers;

Class Config {
    const IP = '192.168.68.57';
    const DEFAULTPROFILEIMAGE = 'cpmad_placeholder.jpg';
}