<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Leaderboard;
use App\Models\Shop;
use App\Models\Transaction;
use App\Http\Controllers\Config;

class GameController extends Controller
{
    //
    public function addNewScore(Request $REQUEST)
    {
        $bool = User::where('token', $REQUEST->token)->first();
        if(!empty($bool))
        {
            $user = Leaderboard::where('userID', $bool->id)->exists();
            if($user)
            {
                $user = Leaderboard::where('userID', $bool->id)->first();

                if($user->score <= $REQUEST->score) //If user score is higher than new scores, it saves
                {
                    $user->score = $REQUEST->score;
                    $user->time = $REQUEST->time;
                    $user->save();
                }
            }
            else
            {
                $score = new Leaderboard;
                $score->userID = $bool->id;
                $score->score = $REQUEST->score;
                $score->time = $REQUEST->time;
                $score->save();
            }  
            
            //Saves if User exist
            $user = User::where('token', $REQUEST->token)->first();
            $user->coins = $user->coins + $REQUEST->score;
            $user->save();
        }
        
        return response()->json(['Message'=>'Score successfully saved.'], 200);
    }

    public function getAll(Request $REQUEST)
    {
        $all = Leaderboard::orderBy('score', 'desc')->get();
        
        foreach($all as $i)
        {
            $user = User::where('id', $i->userID)->first();
            $i['username'] = $user->username;
            $i['url'] = 'http://' . Config::IP .'/CPMAD_GameAPI/profile/' . $user->image;
        }

        return response()->json($all, 200);
    }
}
