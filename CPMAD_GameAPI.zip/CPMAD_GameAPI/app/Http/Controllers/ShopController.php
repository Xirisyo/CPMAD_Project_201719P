<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Leaderboard;
use App\Models\Shop;
use App\Models\Transaction;
use App\Http\Controllers\Config;

class ShopController extends Controller
{
    public function createProduct(Request $REQUEST)
    {
        $product = new Shop;
        $product->name = $REQUEST->name;
        $product->price = $REQUEST->price;
        $product->save();

        return response()->json(['Message'=>'Product successfully created.'], 200);
    }

    public function getAllProducts(Request $REQUEST)
    {
        $products = Shop::all();

        foreach($products as $p)
        {
            $p['url'] = 'http://' . Config::IP .'/CPMAD_GameAPI/products/' . $p->image;
        }

        return response()->json($products, 200);
    }

    public function getProduct(Request $REQUEST)
    {
        $product = Shop::where('id', $REQUEST->id)->first();

        return response()->json($product, 200);
    }
}
