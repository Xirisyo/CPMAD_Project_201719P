<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\Leaderboard;
use App\Models\Shop;
use App\Models\Transaction;
use App\Http\Controllers\Config;

class UserController extends Controller
{
    function imageValidator($image)
    {
        if($image!=null){
            if(($image->getMimeType()=="image/jpeg" or $image->getMimeType()=="image/png" && $image->getSize()<(5000*1024*1024))){
                return true;
            }
            return false;
        }
    }

    public function login(Request $REQUEST)
    {
        $user = User::where('username', $REQUEST->username)
                ->where('password', md5($REQUEST->password))
                ->first();

        if($user)
        {
            date_default_timezone_set('Asia/Singapore');
            $token = Str::random(60);
            $user->token = $token;
            $user->lastLogin = date('Y-m-d H:i:s');
            $user->save();
            return response()->json([
                'Message'=>'Login successfully!',
                'Token'=>$token
            ], 200);
        }

        //If Condition failed
        return response()->json(['Message'=>'Unauthorized'], 400);
    }

    public function register(Request $REQUEST)
    {
        $user = User::where('username', $REQUEST->username)->exists();
        $password = $REQUEST->password;
        if($user)
        {
            return response()->json(['Message'=>'Username has been taken.'], 200);
        }
        else if($password != $REQUEST->confirmPassword)
        {
            return response()->json(['Message'=> 'Passwords does not match.'], 200);
        }

        $user = new User;
        $user->username = $REQUEST->username;
        $user->password = md5($password);
        date_default_timezone_set('Asia/Singapore');
        $token = Str::random(60);
        $user->token = $token;
        $user->lastLogin = date('Y-m-d H:i:s');
        if($user->save())
        {
            return response()->json(['Message'=> 'Account have been successfully created.', 'Token'=>$token], 200);
        }

        return response()->json(['Message'=>'Something went wrong!'], 400);
    }

    public function getProfile(Request $REQUEST)
    {
        $user = User::select('username', 'lastLogin', 'image', 'coins')->where('token', $REQUEST->token)->first();

        if($user)
        {
            $user->url = 'http://' . Config::IP .'/CPMAD_GameAPI/profile/';
            return response()->json($user, 200); //Should also include other
        }

        return response()->json(['Message'=>'Unauthorized'], 400);
    }

    public function updateProfile(Request $REQUEST)
    {
        $image = $REQUEST->file("image");
        $user = User::where('token', $REQUEST->token)->first();
        $password = $REQUEST->password;
        if(!$user)
        {
            return response()->json(['Message'=> 'Unauthorized access'], 401);
        }
        if($password != $REQUEST->confirmPassword)
        {
            return response()->json(['Message'=> 'Passwords does not match.'], 400);
        }
        $user->password = md5($password);
        if($image)//This statement checks whether the picture exist in the header
        {
            if(!$this->imageValidator($image))
                return response()->json(["Message"=> "Posters must be png/jpg, 5mb or less."],401);
            $name = $image->getClientOriginalName();
            $image->move('profile/',$name);

            $user = User::where('token', $REQUEST->token)->first();
            $user->image = $name;
            
            // return response()->json(['Message'=>'Successfully updated profile image'], 400);
        }
        $user->save();

        return response()->json(['Message'=>'Successfully updated '], 200);
    }
}
